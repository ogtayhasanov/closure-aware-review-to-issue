# DeepMatcher supplementary material

The updated manuscript contains Appendix C, "DeepMatcher Reproduction and Exploratory Relevance Audit", and a reference from its short RQ2 paragraph. Existing manuscript text is preserved apart from that reference and the new appendix.

- `main_deepmatcher.tex`: updated full manuscript source; use it with your existing figure and bibliography files.
- `supplement_deepmatcher.tex`: the same appendix as a LaTeX fragment, for inclusion in a separate supplement if desired. Load booktabs, url/hyperref, and placeins in that document.
- `supplement_deepmatcher.pdf`: checked standalone two-page rendering of the appendix.
- `supplement_standalone.tex`: minimal article wrapper for that standalone rendering; the manuscript retains its existing ACM class.
- `DeepMatcher_Comparison_2026-11-03.zip`: reproduction code, historical corpus/query exports, original-label metrics, settings and provenance. Its relevance sheet is the original blank audit template.
- `AI_Relevance_Audit_796_2026-11-03.zip`: completed AI audit, all 796 judgments and reasons, first/second-pass records, restored Firefox evidence, source key, uncertainty bounds, and analysis scripts. Use this archive for the completed judgments.

The AI audit is exploratory and does not establish human-validated ground truth or an unbiased system winner. RRF audit coverage is rank one; other pooled systems have three ranks. Preserve the original-label evaluation separately.

The appendix includes two descriptive tables. No newly confirmatory p-values are claimed, and existing generation judgments and abstention operating points are unchanged.
